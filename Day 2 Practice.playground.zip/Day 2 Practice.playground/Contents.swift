//import UIKit
//
//var str = "Hello, playground"
//
////code challenge:
//
//func evenOdd(value: Int) -> Int {
//    return value
//}
//
//
//
//
//
///*Creating Arrays & Accessig Data*/
//
//var friendsOfAnjali = ["Adriene Mishler","Karlie Kloss" , "Ed Sheeran" , "Betty White" , "Trevor Noah"]
//
//friendsOfAnjali[2] = "Alicia Keys"
//
//friendsOfAnjali.append("Ed Sheeran")
//
//print(friendsOfAnjali)
//
//
///*Dictionaries practice*/
//
//var familyTree = [
//
//    "mother" : "Princy",
//    "sister" : "Lily",
//    "dog" : "Jack",
//    "grandma" : "Cicily",
//    "grandpa" : "Chacko",
//    "bestFriend" : "Peyton",
//    "cousin" : "Lucilla",
//    "godSister" : "Anitha",
//    "godMother" : "Elsy",
//    "yogaGuru" : "Adriene",
//]
//
//print(familyTree)
//
//
///*For-In Loop Practice*/
//
//var sponsors = ["adidas", "Estee Lauder", "Carolina Herrara Good Girl", "Apple", "WeWork"]
//
//for sponsor in sponsors {
//    print("Shout out to \(sponsor) for help making KWK happen!")
//}
//
//var capitals = ["France" : "Paris", "Cuba" : "Havana", "Japan" : "Tokyo"]
//for pair in capitals {
//    print(pair)
//}
//
//var capitals = ["France": "Paris", "Cuba": "Havana", "Japan": "Tokyo"]
//
//for (country, capital) in capitals {
//    print("The capital of \(country) is \(capital).")
//}
//
//var buddies = ["Peyton", "Katie", "Sidney", "Gurman", "Iman"]
//for buddy in buddies {
//    print("Hello,\(buddy)!")
//}
//
//var cityDistance = [
//    "Berlin" : "5203 miles",
//    "Cape Town" : "8758 miles",
//    "Phuket" : "9450 miles",
//]
//
//for (city, distance) in cityDistance {
//  print("I am currently \(distance) away from \(city)!")
//}
//
//var animals = ["red panda", "penguin", "polar bear"]
//
//for index in 0..<animals.count {
//    print("I love " + animals[index])
//}




class Scholar {
    
    var grade = 10
    var studying = "Swift"
    var name = ""     // default this to an empty string!
    
    init(scholarName : String, gradeLevel : Int) {
        name = scholarName
        grade = gradeLevel
    }
    
}
var newScholar = Scholar(scholarName : "Viola", gradeLevel: 10)

print(newScholar)
//-> __lldb_expr_1.Scholar
print(newScholar.name)
//-> Viola
print(newScholar.grade)



class Scholar2 {
    
    var studying = "Swift"
    var name = ""
    var grade = 0
    
    init(scholarName : String, scholarGrade: Int) {
        name = scholarName
        grade = scholarGrade
    }
    
    func writeCode() {
        print("\(name) is busy writing code!")
    }
    
    func danceSong() {
        print("\(name) is happy dancing to songs!")
    }
}
var newScholar2 = Scholar2(scholarName : "Anjali", scholarGrade: 12)

newScholar2.writeCode()
newScholar2.danceSong()


class Icecream {
    var temp = "Cold"
    var flavor = ""
    var toppings = 0


init(icecreamFlavor : String, icecreamToppings : Int) {
    flavor = icecreamFlavor
    toppings = icecreamToppings
}

func eatDessert() {
    print("\(flavor) with \(toppings) toppings is my absolute favorite and makes me so very happy!")
}
}
var newIcecream = Icecream(icecreamFlavor : "Coconut Ice Cream", icecreamToppings : 5)
print(newIcecream.flavor)
print(newIcecream.toppings)
newIcecream.eatDessert()


class Pantry {
    var walkIn = false
    var temperature = 0
    var contents = [String]()
    
    init(pantryWalkIn : Bool, pantryTemp : Int) {
        walkIn = pantryWalkIn
        temperature = pantryTemp
        
        func addFood(food : String) {
            contents.append(food)
        }
    }
}
var pantry = Pantry(pantryWalkIn: true, pantryTemp: 62)

print(pantry.walkIn)
print(pantry.temperature)


