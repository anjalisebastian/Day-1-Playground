//import UIKit
//
//var str = "Hello, playground"
//
////code challenge:
//
//func evenOdd(value: Int) -> Int {
//    return value
//}
//
//
//
//
//
///*Creating Arrays & Accessig Data*/
//
//var friendsOfAnjali = ["Adriene Mishler","Karlie Kloss" , "Ed Sheeran" , "Betty White" , "Trevor Noah"]
//
//friendsOfAnjali[2] = "Alicia Keys"
//
//friendsOfAnjali.append("Ed Sheeran")
//
//print(friendsOfAnjali)
//
//
///*Dictionaries practice*/
//
//var familyTree = [
//
//    "mother" : "Princy",
//    "sister" : "Lily",
//    "dog" : "Jack",
//    "grandma" : "Cicily",
//    "grandpa" : "Chacko",
//    "bestFriend" : "Peyton",
//    "cousin" : "Lucilla",
//    "godSister" : "Anitha",
//    "godMother" : "Elsy",
//    "yogaGuru" : "Adriene",
//]
//
//print(familyTree)
//
//
///*For-In Loop Practice*/
//
//var sponsors = ["adidas", "Estee Lauder", "Carolina Herrara Good Girl", "Apple", "WeWork"]
//
//for sponsor in sponsors {
//    print("Shout out to \(sponsor) for help making KWK happen!")
//}
//
//var capitals = ["France" : "Paris", "Cuba" : "Havana", "Japan" : "Tokyo"]
//for pair in capitals {
//    print(pair)
//}
//
//var capitals = ["France": "Paris", "Cuba": "Havana", "Japan": "Tokyo"]
//
//for (country, capital) in capitals {
//    print("The capital of \(country) is \(capital).")
//}
//
//var buddies = ["Peyton", "Katie", "Sidney", "Gurman", "Iman"]
//for buddy in buddies {
//    print("Hello,\(buddy)!")
//}
//
//var cityDistance = [
//    "Berlin" : "5203 miles",
//    "Cape Town" : "8758 miles",
//    "Phuket" : "9450 miles",
//]
//
//for (city, distance) in cityDistance {
//  print("I am currently \(distance) away from \(city)!")
//}
//
//var animals = ["red panda", "penguin", "polar bear"]
//
//for index in 0..<animals.count {
//    print("I love " + animals[index])
//}




class Scholar {
    
    var grade = 10
    var studying = "Swift"
    var name = ""     // default this to an empty string!
    
    init(scholarName : String, gradeLevel : Int) {
        name = scholarName
        grade = gradeLevel
    }
    
}
var newScholar = Scholar(scholarName : "Viola", gradeLevel: 10)

print(newScholar)
//-> __lldb_expr_1.Scholar
print(newScholar.name)
//-> Viola
print(newScholar.grade)



class Scholar2 {
    
    var studying = "Swift"
    var name = ""
    var grade = 0
    
    init(scholarName : String, scholarGrade: Int) {
        name = scholarName
        grade = scholarGrade
    }
    
    func writeCode() {
        print("\(name) is busy writing code!")
    }
    
    func danceSong() {
        print("\(name) is happy dancing to songs!")
    }
}
var newScholar2 = Scholar2(scholarName : "Anjali", scholarGrade: 12)

newScholar2.writeCode()
newScholar2.danceSong()


class Icecream {
    var temp = "Cold"
    var flavor = ""
    var toppings = 0


init(icecreamFlavor : String, icecreamToppings : Int) {
    flavor = icecreamFlavor
    toppings = icecreamToppings
}

func eatDessert() {
    print("\(flavor) with \(toppings) toppings is my absolute favorite and makes me so very happy!")
}
}
var newIcecream = Icecream(icecreamFlavor : "Coconut Ice Cream", icecreamToppings : 5)
print(newIcecream.flavor)
print(newIcecream.toppings)
newIcecream.eatDessert()


class Food {
    var name = ""
    var calories = 0
    
    init(foodName : String, numberCalories : Int) {
        name = foodName
        calories = numberCalories
    }
    
}

class Pantry {
    var walkIn = false
    var temperature = 0
    var contents = [Food]()
    
    init(pantryWalkIn : Bool, pantryTemp : Int) {
        walkIn = pantryWalkIn
        temperature = pantryTemp
        
    }
    
    func addFood(food : String, calories : Int) {
        let newFood = Food(foodName: food, numberCalories: calories)
        contents.append(newFood)
    }
}
var pantry = Pantry(pantryWalkIn: true, pantryTemp: 62)

print(pantry.walkIn)
print(pantry.temperature)
pantry.addFood(food: "Cracklin Oat Bran", calories: 100)
print(pantry.contents)

pantry.addFood(food: "Pasta Sauce", calories: 50)
pantry.addFood(food: "Cookies", calories: 200)
pantry.addFood(food: "Baking Flour", calories: 150)

for food in pantry.contents {
print("\(food.name) has \(food.calories) calories!")
}

print(pantry.contents[0].name)
print(pantry.contents[0].calories)
