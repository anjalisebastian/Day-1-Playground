import UIKit

var str = "Hello, playground"
print(str)
var first = "Karlie"
var last = "Kloss"
print("\(first)\(last)")
print("\(last)\(first)")
print("\(first) \(last)")
print("\(last) \(first) \(last) \(first)")
print("I love \(first)")

var name = "Anjali"
print("I am \(name)")


var a = 12.0 ; var b = 65.0 ; var c = 31.0 ; var d = 98.0
var e = (a+b+c+d)
print(e/4)

var f = 10.25
var g = 20

print ( f * Double (g))

var favCeleb = "Alicia Keys"
print("Happy Birthday, \(favCeleb)!")
var payday = 10.25 * 20
print(payday)

print(5<3)
print(12>7)
print(6 != 8)
print(7==7)

print("karlie"=="karlie")
print("Karlie" == "karlie")

var luckyNum = 7
luckyNum < 10
luckyNum == 7



var favoriteFood = "sushi"

if (favoriteFood == "Chipotle") {
 print("I don't want a burrito")
    
}

else if (favoriteFood == "Starbucks") {
    print("Latte or Frappe?")
}

else if (favoriteFood == "sushi") {
 print("SCORE!!! Sushi Conveyor Belt pls!!!")
}

else {
    print("I'll pass! Gonna go get sushi")
}


var hasAccount = false

if (hasAccount == true) {
    print("Please log in!")
}

else if (hasAccount == false) {
    print("Let's get some information to create an account for you.")
}


var gradeLevel = 12

if (gradeLevel >= 0 && gradeLevel <= 5) {
    print("Elementary School! Congrats you still a baby!")
}

else if (gradeLevel >= 6 && gradeLevel <= 8) {
    print("You middle schooler you! The awkward phase will end soon!")
}

else if (gradeLevel >= 9 && gradeLevel <= 12) {
    print("High school! Almost done! Thrive!")
}

else {
    print("Either you a baby baby or you don't gotta be in school no more cuz you old!")
}


var numWalks = 0

func walkDog() {
print("put on leash")
print("get poop bags")
print("walk dog")
    numWalks += 1
    print (numWalks)
print("come home!")
}

walkDog()
walkDog()

var breakfast = 0
func chooseCereal() {
    print("go to pantry!")
    print("pick Cheerios or Cracklin' Oat Bran!")
    print("pour milk & enjoy!")
    breakfast += 1
    print (breakfast)
}

chooseCereal()
chooseCereal()

func hello(name: String) {
    print("Hello, \(name)")
}
hello(name: "Trinity")


func walkDogs(numberOfDogs : Int)-> Int {
    let lengthOfWalk = numberOfDogs * 15
    return lengthOfWalk
}
walkDogs(numberOfDogs : 3)
let lengthOfWalk = walkDogs(numberOfDogs : 3)
print("Please walk the dogs. I will expect to see you complete that task in \(lengthOfWalk) minutes!")


func buyCheese(kindOfCheese: String) -> String
{
    print("go to store")
    print("pay for cheese")
    print("eat")
    return kindOfCheese
}

var cheeseType = buyCheese(kindOfCheese: "Provolone")
print (cheeseType)
